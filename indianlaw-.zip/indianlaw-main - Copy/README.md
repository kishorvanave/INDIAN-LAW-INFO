Responsive Website on Indian Law Information System using HTML, CSS &amp; JS
